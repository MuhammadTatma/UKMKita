/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Halaman15Statistik;


import Model.FormatHarga.FormatHarga;
import Model.Order.Order;
import Model.User.User;
import Repository.SellRepository;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.stream.Collectors;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.text.Text;

/**
 *
 * @author HP
 */
public class ChartController implements Initializable {
    
    
    @FXML
    private Label label;
    
    @FXML
    private LineChart<String, Integer> chart;

    @FXML
    private CategoryAxis x;

    @FXML
    private NumberAxis y;

    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        SellRepository sellRepo = new SellRepository();

        ArrayList<Order> semuaOrder = sellRepo.getAll();        

        Map<LocalDate,Integer>banyakPenjualanPerTanggal = semuaOrder.stream()
                .collect(Collectors.groupingBy(order -> order.getTanggal(),Collectors.summingInt(order -> order.getJumlah())));
        
        
        Map<LocalDate,Integer>sorted = sellRepo.getBanyakPenghasilanPerTanggal();
        
        XYChart.Series penjualanPerTanggal = new XYChart.Series();

        penjualanPerTanggal.setName("Jumlah penghasilan per tanggal");
        for(Map.Entry<LocalDate,Integer> iter : sorted.entrySet() ){
            String tanggal = iter.getKey().toString();
            int banyakPenjualan = iter.getValue();   
            final XYChart.Data<String,Integer> temp = new XYChart.Data<>(tanggal, banyakPenjualan);
            temp.nodeProperty().addListener(new ChangeListener<Node>() {
                @Override
                public void changed(ObservableValue<? extends Node> observable, Node oldValue, Node newValue) {
                    if (newValue != null) {
//                        setNodeStyle(temp);
                        tampilNilaiPenghasilan(temp);
                    } 
                }
            });
            
            penjualanPerTanggal.getData().add(temp);
            
        }
        
        
        chart.getData().add(penjualanPerTanggal);
        
//        XYChart.Series series = new XYChart.Series();
//        series.setName("Barang satu");        
//        series.getData().add(new XYChart.Data<>("2021-07-19",15));
//        series.getData().add(new XYChart.Data<>("2021-07-20",10));
//        series.getData().add(new XYChart.Data<>("2021-07-21",5));
//        series.getData().add(new XYChart.Data<>("2021-07-22",35));
//        series.getData().add(new XYChart.Data<>("2021-07-23",25));
//        series.getData().add(new XYChart.Data<>("2021-07-24",6));
//        series.getData().add(new XYChart.Data<>("2021-07-25",34));
//        series.getData().add(new XYChart.Data<>("2021-07-26",19));
//        
//        XYChart.Series series2 = new XYChart.Series();
//        series2.setName("Barang dua");
//        series2.getData().add(new XYChart.Data<>("2021-07-19",13));
//        series2.getData().add(new XYChart.Data<>("2021-07-20",4));
//        series2.getData().add(new XYChart.Data<>("2021-07-21",19));
//        series2.getData().add(new XYChart.Data<>("2021-07-22",3));
//        series2.getData().add(new XYChart.Data<>("2021-07-23",9));
//        series2.getData().add(new XYChart.Data<>("2021-07-24",17));
//        series2.getData().add(new XYChart.Data<>("2021-07-25",4));
//        series2.getData().add(new XYChart.Data<>("2021-07-26",5));
//        chart.getData().addAll(series,series2);
//        
//      

        
        
        
//        for(int i = 0 ; i < activeUser.getTokoUser().getItem().size(); i++){
//            String namaBarang = activeUser.getTokoUser().getItem().get(i).getNama();
//            Integer banyakBarang = activeUser.getTokoUser().getItem().get(i).getStock();
//            XYChart.Series<String,Integer> series = new XYChart.Series<String,Integer>();
//            series.getData().add(new XYChart.Data<String,Integer>(namaBarang,banyakBarang));
//            barChart.getData().add(series);
//        }
        
        
    }    
    
    //agar chart menampilkan nilai banyak penjualan di setiap titik
    private void tampilNilaiData(XYChart.Data<String,Integer>data){
        final Node node = data.getNode();
        final Text text = new Text(data.getYValue().toString());
        node.parentProperty().addListener(new ChangeListener<Parent>() {
            @Override
            public void changed(ObservableValue<? extends Parent> observable, Parent oldValue, Parent newValue) {
                Group parentgroup = (Group)newValue;
                parentgroup.getChildren().add(text);
            }
        });
        node.boundsInParentProperty().addListener(new ChangeListener<Bounds>() {
            @Override public void changed(ObservableValue<? extends Bounds> ov, Bounds oldBounds, Bounds bounds) {
                
                text.setLayoutX(
                    Math.round(
                      bounds.getMinX() + bounds.getWidth() / 2 - text.prefWidth(-1) / 2
                    )
                );
                text.setLayoutY(
                    Math.round(
                      bounds.getMinY() - text.prefHeight(-1) * 0.5
                    )
                );
            }
        });
    }
    
    //agar chart menampilkan nilai penghasilan di setiap titik
    private void tampilNilaiPenghasilan(XYChart.Data<String,Integer>data){
        final Node node = data.getNode();
        final Text text = new Text(FormatHarga.formatHarga(data.getYValue()));
        node.parentProperty().addListener(new ChangeListener<Parent>() {
            @Override
            public void changed(ObservableValue<? extends Parent> observable, Parent oldValue, Parent newValue) {
                Group parentgroup = (Group)newValue;
                parentgroup.getChildren().add(text);
            }
        });
        node.boundsInParentProperty().addListener(new ChangeListener<Bounds>() {
            @Override public void changed(ObservableValue<? extends Bounds> ov, Bounds oldBounds, Bounds bounds) {
                
                text.setLayoutX(
                    Math.round(
                      bounds.getMinX() + bounds.getWidth() / 2 - text.prefWidth(-1) / 2
                    )
                );
                text.setLayoutY(
                    Math.round(
                      bounds.getMinY() - text.prefHeight(-1) * 0.5
                    )
                );
            }
        });
    }
}
